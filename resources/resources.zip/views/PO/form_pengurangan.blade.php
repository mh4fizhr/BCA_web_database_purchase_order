<?php $page = "Pengurangan"; ?>
@extends('sidebar')

@section('content')


<script
  src="https://code.jquery.com/jquery-2.2.4.js"
  integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
  crossorigin="anonymous"></script>
<script type="text/javascript">
    // $(function () {
    //     $("#tgl_cutoff").show();
    //     $("#tgl_cutoff_disabled").hide();
    //     $("#sewa").change(function () {
    //         if ($(this).val() == "null") {
    //             $("#tgl_cutoff").show();
    //             $("#tgl_cutoff_disabled").hide();
    //         } else if($(this).val() == "Driver") {
    //             $("#tgl_cutoff").hide();
    //             $("#tgl_cutoff_disabled").show();
    //         } else{
    //             $("#mobil").show();
    //             $("#driver").show();
    //         }
    //   });
        
    // });

    $(document).ready(function(){
        var i = 1;
        $('.add').click(function(){
          i++;
          $("#tambuh").clone().appendTo( ".tempat_tambah" );
        });
    });
</script>

<div class="header bg-primary pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h1 class=" text-white d-inline-block mb-0">{{$page}} PO</h1>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">Purchase Order</a></li>
                  <li class="breadcrumb-item active" aria-current="page">{{$page}} PO</li>
                </ol>
              </nav>
            </div>

            <!-- <div class="col-lg-6 col-5 text-right">
              <a href="#" class="btn btn-sm btn-neutral">New</a>
              <a href="#" class="btn btn-sm btn-neutral">Filters</a>
            </div> -->
          </div>
          <!-- Card stats -->

        </div>
      </div>
    </div>
    <div class="container-fluid mt--6">
      <section class="content">
        <div class="row">
          <div class="col-12">
            <form action="{{url('/backend/po/edit/'.$pos->id)}}" method="post" role="form">
              {{ csrf_field() }}
                <div class="card mb-4">
                  <!-- Card header -->
                  <div class="card-header">
                    <h3 class="mb-0">Form Purchase Order</h3>
                  </div>
                  <!-- Card body -->
                  <div class="card-body">
                    <!-- Form groups used in grid -->
                    <div class="row">
                      <div class="col-md-12">
                        <div class="row">
                          <div class="col-md-12">
                            <div class="row">
                              <div class="col-md-2">
                                    <div class="form-group">
                                      <label class="form-control-label ml-3 mt-3" for="example3cols1Input">No PO :</label>
                                    </div>
                              </div>
                              
                              <div class="col-md-10">
                                    <div class="form-group">
                                      <input type="text" class="form-control" name="nopo_pengurangan" value="" id="example3cols2Input" placeholder="" required>
                                      <!-- @foreach($nopos as $nopo)
                                        @if($nopo->id == $pos->NoPo)
                                          <input type="text" class="form-control" value="{{$nopo->NoPo}}" id="example3cols2Input" placeholder="Example : 256/JS/BPD/KPS/2017" disabled="">
                                        @endif            
                                      @endforeach -->
                                    </div>
                              </div>
                              <div class="col-md-2">
                                <div class="form-group" id="contoh_tambahan">
                                  <label class="form-control-label ml-3 mt-3" for="example3cols1Input">Jenis Sewa :</label>
                                </div>
                              </div>
                              <div class="col-md-4">
                                <div class="form-group">
                                  <input type="text" class="form-control" value="{{$pos->Sewa_sementara}}" id="example3cols2Input" placeholder="Example : 256/JS/BPD/KPS/2017" disabled="">
                                </div>
                              </div>
                              <div class="col-md-2">
                                <div class="form-group pull-right float-right">
                                  <label class="form-control-label ml-5 mt-3" for="example3cols1Input">Kurangi :</label>
                                </div>
                              </div>
                              <div class="col-md-4">
                                <div class="form-group">
                                  <select class="form-control" id="sewa" name="sewa">
                                    @if($pos->Sewa_sementara == "Mobil+Driver")
                                      <option value="Mobil+Driver">Mobil+Driver</option>
                                      <!-- <option value="Mobil">Mobil</option> -->
                                      <option value="Driver">Driver</option>
                                    @elseif($pos->Sewa_sementara == "Driver")
                                      <option value="Driver">Driver</option>
                                    @elseif($pos->Sewa_sementara == "Mobil")
                                      <option value="Mobil">Mobil</option>
                                    @endif
                                  </select>
                                </div>
                              </div>

                              <div class="col-md-2">
                                <div class="form-group">
                                  <label class="form-control-label ml-3 mt-3" for="example3cols1Input">Cut Off</label>
                                </div>
                              </div>
                              <div class="col-md-10">
                                <div class="form-group">
                                  <input class="form-control date" type="text" placeholder="mm / dd / yyyy" name="tgl_cutoff" id="example-date-input">
                                </div>
                              </div>

                            </div>
                            
                          </div>
                          <div class="col-md-6" >

                            @if($pos->Tgl_cutoff == '')
                                <input type="hidden" name="sewa_lama" value="{{$pos->Sewa}}">
                                <input type="hidden" name="nopo_lama" value="{{$pos->NoPo}}">
                                @else
                                  @if($pos->Sewa == 'Mobil+Driver')
                                    @if($pos->Pengurangan == 'Driver')
                                      <input type="hidden" name="sewa_sementara" value="Mobil">
                                      <input type="hidden" name="sewa_lama" value="Mobil">
                                    @elseif($pos->Pengurangan == 'Mobil')
                                      <input type="hidden" name="sewa_sementara" value="Driver">
                                      <input type="hidden" name="sewa_lama" value="Driver">
                                    @else
                                      <input type="hidden" name="sewa_sementara" value="null">
                                      <input type="hidden" name="sewa_lama" value="null">
                                    @endif
                                  @elseif($pos->Sewa == 'Mobil')
                                    @if($pos->Pengurangan == 'Mobil')
                                      <input type="hidden" name="sewa_sementara" value="null">
                                      <input type="hidden" name="sewa_lama" value="null">
                                    @endif
                                  @elseif($pos->Sewa == 'Driver')
                                    @if($pos->Pengurangan == 'Driver')
                                      <input type="hidden" name="sewa_sementara" value="null">
                                      <input type="hidden" name="sewa_lama" value="null">
                                    @endif
                                  @endif
                                  <input type="hidden" name="nopo_lama" value="{{$pos->Nopo_pengurangan}}">
                                @endif

                          </div>
                        </div>
                      </div>
                    </div>

                    
                </div>
                <div class="card-footer">
                  <div class="row">
                    <div class="col-md-3"></div>
                    <div class="col-md-9">
                      <div class="form-group float-right pull-right">
                        <a href="javascript:history.back()" type="button" class="btn btn-default">Back</a>
                        <button type="submit" id="save" class="btn btn-success pl-5 pr-5">Submit</button>
                      </div>
                    </div>
                  </div>
                </div>
            </form>
            <div class="tempat_tambah">
              
            </div>

          </div>
        </div>
      </div>
    </section>



<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tbody tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});

// $(document).ready(function(){
//   var count = 1;


//   function dynamic_field(number)
//   {
//     var html = '<div class="row">'

//     html += '<p>asfasdad</p>';

//     if(number > 1)
//     {
//       html += '<button type="submit" id="tombol_remove" class="btn btn-danger pl-5 pr-5 pull-right float-right">Remove</button></div>';
//       $('#tombol_remove').append(html)
//     }else{

//     }
//   }

//   $('.add').click(function(){
//     count++;
//     dynamic_field(count);
//     $('#dynamic_field').append('<p>ketambah nih</p><br>')  
//   });

//   $(document).on('click', '#tombol_remove', function(){
//     count--;
//     dynamic_field(count);
//   });

//   $(#dynamic_field).on('submit', function(event){
//     event.preventDefault();
//     $.ajax({
//       url:'{{url("/backend/po/create")}}',
//       method:'post',
//       data:$(this).serialize(),
//       dataType:'json',
//       beforeSend:function(){
//         $('#save').attr('disabled','disabled');
//       },
//       success:function(data)
//       {
//         if (data.error) 
//         {
//           var error_html = '';
//           for(var count = 0;count < data.error.length; count++)
//           {
//             error_html += '<p>'+data.error[count]+'<p>';
//           }
//           $('#result').html('<div class="alert alert-danger">'+error_html+'</div>');
//         }
//         else
//         {
//           dynamic_field(1);
//           $('#result').html('<div class="alert alert-success">'+data.success+'</div>');
//         }
//         $('#save').attr('disabled', false);
//       }
//     })
//   });

//   });
</script>


@endsection






