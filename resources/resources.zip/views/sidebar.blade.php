<!--
=========================================================
* Argon Dashboard - v1.2.0
=========================================================
* Product Page: https://www.creative-tim.com/product/argon-dashboard


* Copyright  Creative Tim (http://www.creative-tim.com)
* Coded by www.creative-tim.com



=========================================================
* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
-->
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Start your development with a Dashboard for Bootstrap 4.">
  <meta name="author" content="Creative Tim">
  <meta name="csrf_token" content="{{ csrf_token() }}" />
  
  <title>BCA - Pengadaan Mobil</title>
  <!-- Favicon -->
  <link rel="icon" href="{{asset('/dist/img/BCA-logo.png')}}" type="image/png">
  <!-- Fonts -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
  <!-- Icons -->
  <link rel="stylesheet" href="{{asset('dist/argon/vendor/nucleo/css/nucleo.css')}}" type="text/css">
  <link rel="stylesheet" href="{{asset('dist/argon/vendor/@fortawesome/fontawesome-free/css/all.min.css')}}" type="text/css">
  
  <!-- Page plugins -->
  <link rel="stylesheet" href="{{asset('dist/argon/vendor/animate.css/animate.min.css')}}">

  <link rel="stylesheet" href="{{asset('dist/argon/vendor/datatables.net-bs4/css/dataTables.bootstrap4.min.css')}}">
  <link rel="stylesheet" href="{{asset('dist/argon/vendor/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css')}}">
  <link rel="stylesheet" href="{{asset('dist/argon/vendor/datatables.net-select-bs4/css/select.bootstrap4.min.css')}}">
  <link rel="stylesheet" href="{{asset('dist/argon/vendor/select2/dist/css/select2.min.css')}}">
  <!--   <link rel="stylesheet" href="{{asset('dist/argon/vendor/sweetalert2/dist/sweetalert2.min.css')}}"> -->

  




  <!-- Argon CSS -->
  <link rel="stylesheet" href="{{asset('dist/argon/css/argon.css?v=1.2.0')}}" type="text/css">
  <!-- <link href="{{asset('dist/bootstrap4-editable/css/bootstrap-editable.css')}}" rel="stylesheet"> -->
<!--   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->
  <link rel="stylesheet" href="{{asset('dist/argon/vendor/@fortawesome/fontawesome-free/font-awesome.min.css')}}">

  <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
</head>

<body class="g-sidenav-show g-sidenav-pinned">
  <!-- Sidenav -->
  <nav class="sidenav navbar navbar-vertical  fixed-left  navbar-expand-xs navbar-light bg-white" id="sidenav-main">
    <div class="scrollbar-inner">
      <!-- Brand -->
      <div class="sidenav-header  d-flex  align-items-center">
              <a class="navbar-brand" href="{{url('/backend/dashboard')}}">
                <img src="{{asset('dist/argon/img/BCA-logo4.png')}}"
                     alt="AdminLTE Logo"
                     class="brand-image elevation-2"
                     style="opacity: .9">
                <span class="brand-text h3 text-primary"></b></span>
              </a>
            
            </div>
      
      <div class="navbar-inner">
        <!-- Collapse -->
        <div class="collapse navbar-collapse" id="sidenav-collapse-main">
          <!-- Nav items -->

          <hr class="my-3 mt--3">
          @if(auth::user()->status != 'admin')
          <!-- Heading -->
<!--           <h6 class="navbar-heading p-0 text-muted">
            <span class="docs-normal">View Area</span>
          </h6> -->
          <ul class="navbar-nav">
            <li class="nav-item">
              <a href="{{url('/backend/dashboard')}}" class="nav-link <?php if($page == "Dashboard" || $page == "Service" || $page == "mcu") echo "active";?>" >
                  <i class="fas fa-tv nav-icon"></i>
                  <span>Database</span>
              </a>
            </li>

            <li class="nav-item">
              <a href="{{url('/backend/po/table')}}" class="nav-link <?php if($page == "DPO" || $page == "Penambahan" || $page == "Pengurangan" || $page == "Relokasi") echo "active";?>" >
                  <i class="ni ni-paper-diploma nav-icon"></i>
                  <span>Purchase Order - 
                    @if(auth::user()->status == 'pengada')
                      BPD
                    @elseif(auth::user()->status == 'operasional')
                      BOP
                    @endif
                  </span>
              </a>
            </li>

            <li class="nav-item">
              <a href="{{url('/backend/driver')}}" class="nav-link <?php if($page == "Driver") echo "active";?>" >
                  <i class="fa fa-user-tie nav-icon"></i>
                  <span >Driver</span>
              </a>
            </li>

          </ul>
          <hr class="my-3">
          <!-- Heading -->
<!--           <h6 class="navbar-heading p-0 text-muted">
            <span class="docs-normal">Admin Area</span>
          </h6> -->

          <ul class="navbar-nav">
            <li class="nav-item">
              <a href="{{url('/backend/cabang')}}" class="nav-link <?php if($page == "Cabang") echo "active";?>" >
                  <i class="fa fa-building nav-icon"></i>
                  <span>Cabang</span>
              </a>
            </li>
           <li class="nav-item">
              <a href="{{url('/backend/mobil')}}" class="nav-link <?php if($page == "Mobil") echo "active";?>" >
                  <i class="fa fa-car nav-icon"></i>
                  <span>Mobil</span>
              </a>
            </li>

            <li class="nav-item">

              <a class="nav-link <?php if($page == "UMP") echo 'active'; else echo 'collapsed'; ?>" href="#navbar-forms" data-toggle="collapse" role="button" aria-expanded="<?php if($page == "UMP") echo 'true'; else echo 'false'; ?>" aria-controls="navbar-forms">
                <i class="ni ni-single-copy-04 "></i>
                <span class="nav-link-text">UMP</span>
              </a>
              <div class="collapse <?php if($page == "UMP") echo 'show'; ?>" id="navbar-forms" style="">
                <ul class="nav nav-sm flex-column">
                  <li class="nav-item">
                    <a href="{{url('/backend/ump/harga_ump')}}" class="nav-link">
                      <i class="fas fa-money-bill-wave nav-icon"></i>
                      <span>Harga_ump</span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="{{url('/backend/ump/jkk')}}" class="nav-link ">
                      <i class="fas fa-percent nav-icon"></i>
                      <span>Jkk</span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="{{url('/backend/ump/kota')}}" class="nav-link">
                      <i class="fas fa-map-marker-alt nav-icon"></i>
                      <span>Kota</span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="{{url('/backend/ump/tahun')}}" class="nav-link ">
                      <i class="fas fa-calendar nav-icon"></i>
                      <span>Tahun</span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="{{url('/backend/vendor')}}" class="nav-link">
                      <i class="ni ni-building nav-icon"></i>
                      <span>Vendor</span>
                    </a>
                  </li>
                </ul>
              </div>
            </li>




            <li class="nav-item">
              <a class="nav-link <?php if($page == "Report") echo 'active'; else echo 'collapsed'; ?>" href="#navbar-forms2" data-toggle="collapse" role="button" aria-expanded="<?php if($page == "Report") echo 'true'; else echo 'false'; ?>" aria-controls="navbar-forms2">
                <i class="fas fa-file-signature "></i>
                <span class="nav-link-text">Report</span>
              </a>
              <div class="collapse <?php if($page == "Report") echo 'show'; ?>" id="navbar-forms2" style="">
                <ul class="nav nav-sm flex-column">
                  <li class="nav-item">
                    <a href="{{url('/backend/report/service')}}" class="nav-link">
                      <i class="fas fa-tools nav-icon"></i>
                      <span>Service</span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="{{url('/backend/report/salon')}}" class="nav-link">
                      <i class="fas fa-car nav-icon"></i>
                      <span>Salon</span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="{{url('/backend/report/mcu')}}" class="nav-link">
                      <i class="fas fa-tshirt nav-icon"></i>
                      <span>Seragam & MCU</span>
                    </a>
                  </li>
                </ul>
              </div>
            </li>

          </ul>
          
          <!-- <hr class="my-3">
          <h6 class="navbar-heading p-0 text-muted">
            <span class="docs-normal">Data Area</span>
          </h6>

          <ul class="navbar-nav">

            <li class="nav-item">
              <a class="nav-link <?php if($page == "Backup") echo 'active'; else echo 'collapsed'; ?>" href="#navbar-forms3" data-toggle="collapse" role="button" aria-expanded="<?php if($page == "Backup") echo 'true'; else echo 'false'; ?>" aria-controls="navbar-forms3">
                <i class="fas fa-cogs "></i>
                <span class="nav-link-text">Backup Restore data</span>
              </a>
              <div class="collapse <?php if($page == "Backup") echo 'show'; ?>" id="navbar-forms3" style="">
                <ul class="nav nav-sm flex-column">
                  <li class="nav-item">
                    <a href="/backend/backup" class="nav-link">
                      <i class="fas fa-download nav-icon"></i>
                      <span>Backup</span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="/backend/restore" class="nav-link">
                      <i class="fas fa-upload nav-icon"></i>
                      <span>Restore</span>
                    </a>
                  </li>
                </ul>
              </div>
            </li>
          </ul> -->
          @endif
          @if(auth::user()->status == 'admin')
          
          <!-- Heading -->
          <h6 class="navbar-heading p-0 text-muted">
            <span class="docs-normal">Super Admin</span>
          </h6>
          <ul class="navbar-nav">
            <li class="nav-item">
              <a href="{{url('/backend/admin/po')}}" class="nav-link <?php if($page == "db_po") echo "active";?>" >
                  <i class="fas fa-database nav-icon"></i>
                  <span>DB Purchase Order</span>
              </a>
            </li>

            <li class="nav-item">
              <a class="nav-link <?php if($page == "db_driver") echo 'active'; else echo 'collapsed'; ?>" href="#navbar-forms3" data-toggle="collapse" role="button" aria-expanded="<?php if($page == "db_driver") echo 'true'; else echo 'false'; ?>" aria-controls="navbar-forms3">
                <i class="fas fa-database"></i>
                <span class="nav-link-text">DB Driver</span>
              </a>
              <div class="collapse <?php if($page == "db_driver") echo 'show'; ?>" id="navbar-forms3" style="">
                <ul class="nav nav-sm flex-column">
                  <li class="nav-item">
                    <a href="{{url('/backend/admin/driver')}}" class="nav-link">
                      <i class="fas fa-user-tie nav-icon"></i>
                      <span>Driver</span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="{{url('/backend/admin/pkwt')}}" class="nav-link">
                      <i class="fas fa-calendar nav-icon"></i>
                      <span>PKWT</span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="{{url('/backend/admin/driver')}}" class="nav-link">
                      <i class="fas fa-clock nav-icon"></i>
                      <span>History</span>
                    </a>
                  </li>
                </ul>
              </div>
            </li>
<!-- 
            <li class="nav-item">
              <a href="{{url('/backend/admin/driver')}}" class="nav-link <?php if($page == "db_driver") echo "active";?>" >
                  <i class="fas fa-database nav-icon"></i>
                  <span>DB Driver</span>
              </a>
            </li> -->

            <li class="nav-item">
              <a href="{{url('/backend/admin/cabang')}}" class="nav-link <?php if($page == "db_cabang") echo "active";?>" >
                  <i class="fas fa-database nav-icon"></i>
                  <span>DB Cabang</span>
              </a>
            </li>

            <li class="nav-item">
              <a href="{{url('/backend/admin/mobil')}}" class="nav-link <?php if($page == "db_mobil") echo "active";?>" >
                  <i class="fas fa-database nav-icon"></i>
                  <span>DB Mobil</span>
              </a>
            </li>

            <li class="nav-item">
              <a class="nav-link <?php if($page == "db_hargaump") echo 'active'; else echo 'collapsed'; ?>" href="#navbar-forms4" data-toggle="collapse" role="button" aria-expanded="<?php if($page == "db_hargaump") echo 'true'; else echo 'false'; ?>" aria-controls="navbar-forms4">
                <i class="fas fa-database"></i>
                <span class="nav-link-text">DB UMP</span>
              </a>
              <div class="collapse <?php if($page == "db_hargaump") echo 'show'; ?>" id="navbar-forms4" style="">
                <ul class="nav nav-sm flex-column">
                  <li class="nav-item">
                    <a href="{{url('/backend/admin/hargaump')}}" class="nav-link">
                      <i class="fas fa-money-bill-wave nav-icon"></i>
                      <span>Harga Ump</span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="{{url('/backend/admin/jkk')}}" class="nav-link">
                      <i class="fas fa-percent nav-icon"></i>
                      <span>Jkk</span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="{{url('/backend/admin/kota')}}" class="nav-link">
                      <i class="fas fa-map-marker-alt nav-icon"></i>
                      <span>Kota</span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="{{url('/backend/admin/tahun')}}" class="nav-link">
                      <i class="fas fa-calendar nav-icon"></i>
                      <span>Tahun</span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="{{url('/backend/admin/vendor')}}" class="nav-link">
                      <i class="ni ni-building nav-icon"></i>
                      <span>Vendor</span>
                    </a>
                  </li>
                </ul>
              </div>
            </li>

            <li class="nav-item">
              <a href="{{url('/backend/admin/report')}}" class="nav-link <?php if($page == "db_report") echo "active";?>" >
                  <i class="fas fa-database nav-icon"></i>
                  <span>DB Report</span>
              </a>
            </li>

             <li class="nav-item">
              <a href="{{url('/backend/user')}}" class="nav-link <?php if($page == "User") echo "active";?>">
                  <i class="ni ni-circle-08 nav-icon"></i>
                  <span>User <b></b></span>
              </a>
            </li>

          </ul>
          @endif



          <!-- <hr class="my-3">

          <h6 class="navbar-heading p-0 text-muted">
            <span class="docs-normal">On Maintanance</span>
          </h6>

          <ul class="navbar-nav">

            <li class="nav-item">
              <a href="{{url('/backend/service')}}" class="nav-link <?php if($page == "Service") echo "active";?>">
                  <i class="ni ni-settings text-info nav-icon"></i>
                  <span>Service <b>(on maintanace)</b></span>
              </a>
            </li>
          </ul> -->
          <!-- Divider -->
          <!-- <hr class="my-3">
  
          <h6 class="navbar-heading p-0 text-muted">
            <span class="docs-normal">Documentation</span>
          </h6>
    
          <ul class="navbar-nav mb-md-3">
            <li class="nav-item">
              <a class="nav-link" href="https://demos.creative-tim.com/argon-dashboard/docs/getting-started/overview.html" target="_blank">
                <i class="ni ni-spaceship"></i>
                <span class="nav-link-text">Getting started</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="https://demos.creative-tim.com/argon-dashboard/docs/foundation/colors.html" target="_blank">
                <i class="ni ni-palette"></i>
                <span class="nav-link-text">Foundation</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="https://demos.creative-tim.com/argon-dashboard/docs/components/alerts.html" target="_blank">
                <i class="ni ni-ui-04"></i>
                <span class="nav-link-text">Components</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="https://demos.creative-tim.com/argon-dashboard/docs/plugins/charts.html" target="_blank">
                <i class="ni ni-chart-pie-35"></i>
                <span class="nav-link-text">Plugins</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link active active-pro" href="upgrade.html">
                <i class="ni ni-send text-dark"></i>
                <span class="nav-link-text">Upgrade to PRO</span>
              </a>
            </li>
          </ul> -->
        </div>
      </div>
    </div>
  </nav>
  <!-- Main content -->

  @include('navbar')

  @yield('content')

  @include('footer')
