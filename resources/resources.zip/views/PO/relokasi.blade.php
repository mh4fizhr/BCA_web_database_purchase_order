<?php $page = "Relokasi"; ?>
@extends('sidebar')

@section('content')



<div class="header bg-primary pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-7 col-7">
              <h1 class=" text-white d-inline-block mb-0">{{$page}} Table</h1>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">Purchase Order</a></li>
                  <li class="breadcrumb-item active" aria-current="page">table</li>
                </ol>
              </nav>
            </div>
            <div class="col-lg-5 col-5 text-right">
              
              <!-- <a href="/backend/po/form_add" class="btn btn-success float-right pull-right" ><i class="fas fa-plus"></i> Add <?php echo $page ?></a> -->
                <ul class="nav nav-pills nav-fill flex-column flex-sm-row" id="tabs-text" role="tablist" >
                  <li class="nav-item">
                    <a class="nav-link mb-sm-3 mb-md-0 active" id="tabs-text-1-tab" data-toggle="tab" href="#tabs-text-1" role="tab" aria-controls="tabs-text-1" aria-selected="true" style="font-size: 11px">Single Relokasi</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link mb-sm-3 mb-md-0" id="tabs-text-2-tab" data-toggle="tab" href="#tabs-text-2" role="tab" aria-controls="tabs-text-2" aria-selected="false" style="font-size: 11px">Multiple Relokasi</a>
                  </li>
                  <li class="nav-item text-right">
                    <a href="{{url('/backend/po/table')}}" type="button" class="btn btn-default">Back</a>
                  </li>
                </ul>
            </div>
            <!-- <div class="col-lg-6 col-5 text-right">
              <a href="#" class="btn btn-sm btn-neutral">New</a>
              <a href="#" class="btn btn-sm btn-neutral">Filters</a>
            </div> -->
          </div>
          <!-- Card stats -->

        </div>
      </div>
    </div>
    <div class="container-fluid mt--6">
      <section class="content">
        <div class="row">
          <div class="col-12">
            <div class="card pb-4 pt--8">
              <div class="card-header border-0">
                
              </div>
              <div class="tab-content" id="myTabContent">

                <div class="tab-pane fade show active" id="tabs-text-1" role="tabpanel" aria-labelledby="tabs-icons-text-1-tab">
                    <div class="table-responsive">
                      <table class="table align-items-center table-flush table-hover text-center mydatatable" id="myTable" style="width: 100%">
                        <thead class="">
                          <tr>
                            <th scope="col" rowspan="2"><b>No</b></th>
                            <th scope="col" colspan="3" class="bg-yellow text-white"><b>Cabang Lama</b></th>
                            <th scope="col" colspan="4" class="bg-info text-white"><b>Cabang Baru</b></th>               
                            <th scope="col" rowspan="2"><b>Sewa</b></th>   
                            <th scope="col" rowspan="2"><b>No.Pol</b></th>  
                            <th scope="col" rowspan="2"><b>Action</b></th>
                          </tr>
                          <tr>
                            <th scope="col" class="bg-yellow text-white"><b>No PO</b></th>
                            <th scope="col" class="bg-yellow text-white"><b>Cabang</b></th>
                            <th scope="col" class="bg-yellow text-white"><b>Kota</b></th>
                            <th scope="col" class="bg-info text-white"><b>No PO</b></th>
                            <th scope="col" class="bg-info text-white"><b>Cabang</b></th>
                            <th scope="col" class="bg-info text-white"><b>Kota</b></th>
                            <th scope="col" class="bg-info text-white"><b>Efektif</b></th>
                          </tr>
                        </thead>
                        <tbody>
                             <?php 
                            $i = 1;
                            $currentDateTime = date('Y-m-d H:i:s');
                          ?>
                          @foreach($pos as $po)
                          @if($po->status == 1 && ($po->SelesaiSewa <= $currentDateTime || ($po->Tgl_cutoff != '' && $po->Tgl_cutoff <= $currentDateTime && $po->Sewa_sementara == 'null')))
                          @elseif($po->status == '0')
                          @else
                          <tr role="row" class="odd "> 
                            <td>{{$i}}</td>
                            <td>{{$po->Nopo_permanent}}</td>
                            <!-- <td>
                              @foreach($nopos as $nopo)
                                @if($po->NoPo == $nopo->id)
                                  {{$nopo->NoPo}}
                                @endif
                              @endforeach
                            </td> -->
                            @foreach($cabangs as $cabang)
                              @if($po->Cabang_id == $cabang->id)
                              <td>{{$cabang->KodeCabang}} - {{$cabang->NamaCabang}}</td>
                              <td>{{$cabang->Kota}}</td>
                              @endif
                            @endforeach
                            
                            @if($po->Cabang_relokasi == '')
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                            @else
                                  
                                  <td>{{$po->Nopo_relokasi}}</td>
                                  @foreach($cabangs as $cabang)
                                
                                    @if($po->Cabang_relokasi == $cabang->id)
                                    <td>{{$cabang->KodeCabang}} - {{$cabang->NamaCabang}}</td>
                                    <td>{{$cabang->Kota}}</td>
                                    @endif
                                
                                  @endforeach
                                  
                            @endif
                            <td>
                              @if($po->Efisien_relokasi == '')
                                -
                              @else
                                {{$po->Efisien_relokasi->format('d-M-Y')}}
                              @endif
                            </td>

                            <td>
                              {{$po->Sewa_sementara}}
                            </td>
                            
                            <td> 
                              @if($po->Nopol == 'null')
                                Tanpa Unit
                              @elseif($po->Nopol == '')
                                Tanpa Unit
                              @else
                                {{$po->Nopol}}
                              @endif
                            </td>

                            <td>
                              <a class="btn btn-primary btn-sm" href="{{url('/backend/po/form_relokasi/'.$po->id)}}">
                                  Relokasi
                              </a>
                            </td>

                            <?php $i++; ?>
                          </tr>
                          @endif
                          @endforeach
                           
                        </tbody>
                      </table>
                    </div>
                </div>




















                <div class="tab-pane fade" id="tabs-text-2" role="tabpanel" aria-labelledby="tabs-icons-text-2-tab">
                  <form action="{{url('/backend/po/form_relokasi')}}" method="post" role="form">
                    {{ csrf_field() }}
                    <div class="table-responsive">
                      <table class="table align-items-center table-flush table-hover text-center mydatatable" id="myTable" style="width: 100%">
                        <thead class="">
                          <tr>
                            <th scope="col" rowspan="2"><b>No</b></th>
                            <th scope="col" colspan="3" class="bg-yellow text-white"><b>Cabang Lama</b></th>
                            <th scope="col" colspan="4" class="bg-info text-white"><b>Cabang Baru</b></th>               
                            <th scope="col" rowspan="2"><b>Sewa</b></th>   
                            <th scope="col" rowspan="2"><b>No.Pol</b></th>  
                            <th scope="col" rowspan="2">
                              <input type="submit" class="btn btn-primary btn-sm text-white" value="Relokasi">
                            </th>
                          </tr>
                          <tr>
                            <th scope="col" class="bg-yellow text-white"><b>No PO</b></th>
                            <th scope="col" class="bg-yellow text-white"><b>Cabang</b></th>
                            <th scope="col" class="bg-yellow text-white"><b>Kota</b></th>
                            <th scope="col" class="bg-info text-white"><b>No PO</b></th>
                            <th scope="col" class="bg-info text-white"><b>Cabang</b></th>
                            <th scope="col" class="bg-info text-white"><b>Kota</b></th>
                            <th scope="col" class="bg-info text-white"><b>Efektif</b></th>
                          </tr>
                        </thead>
                        <tbody>
                             <?php 
                            $i = 1;
                          ?>
                          @foreach($pos as $po)
                          @if($po->status == 1 && ($po->SelesaiSewa <= $currentDateTime || ($po->Tgl_cutoff != '' && $po->Tgl_cutoff <= $currentDateTime && $po->Sewa_sementara == 'null')))
                          @elseif($po->status == '0')
                          @else
                          <tr role="row" class="odd ">
                            <td>{{$i}}</td>
                            <td>{{$po->Nopo_permanent}}</td>
                            <!-- <td>
                              @foreach($nopos as $nopo)
                                @if($po->NoPo == $nopo->id)
                                  {{$nopo->NoPo}}
                                @endif
                              @endforeach
                            </td> -->
                            @foreach($cabangs as $cabang)
                              @if($po->Cabang_id == $cabang->id)
                              <td>{{$cabang->KodeCabang}} - {{$cabang->NamaCabang}}</td>
                              <td>{{$cabang->Kota}}</td>
                              @endif
                            @endforeach
                            
                            @if($po->Cabang_relokasi == '')
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                            @else
                                  
                                  <td>{{$po->Nopo_relokasi}}</td>
                                  @foreach($cabangs as $cabang)
                                
                                    @if($po->Cabang_relokasi == $cabang->id)
                                    <td>{{$cabang->KodeCabang}} - {{$cabang->NamaCabang}}</td>
                                    <td>{{$cabang->Kota}}</td>
                                    @endif
                                
                                  @endforeach
                                  
                            @endif
                            <td>
                              @if($po->Efisien_relokasi == '')
                                -
                              @else
                                {{$po->Efisien_relokasi->format('d-M-Y')}}
                              @endif
                            </td>

                            <td>
                              {{$po->Sewa_sementara}}
                            </td>
                            
                            <td> 
                              {{$po->Nopol}}
                            </td>

                            <td>
                                <input type="checkbox" id="relokasi{{$i}}" name="relokasi[]" value="{{$po->id}}">
                            </td>

                            <?php $i++; ?>
                          </tr>
                          @endif
                          @endforeach
                           
                        </tbody>
                      </table>
                    </div>
                </div>
              </form>
              </div>

                
                
              
              
            <!-- /.card -->
            
          </div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

            
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </section>
    <!-- /.content -->
    </div>



<script>

  


</script>

@include('PO.add');

@endsection






