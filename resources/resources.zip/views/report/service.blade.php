<?php $page = "Report";
      $page2 = "Service" ?>
@extends('sidebar')

@section('content')

<div class="header bg-primary pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-8 col-8">
              <h1 class=" text-white d-inline-block mb-0">{{$page2}} Table</h1>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">{{$page2}}</a></li>
                  <li class="breadcrumb-item active" aria-current="page">table</li>
                </ol>
              </nav>
            </div>
            <div class="col-lg-4">
              <ul class="nav nav-pills nav-fill flex-column flex-sm-row" id="tabs-text" role="tablist" >
                <li class="nav-item">
                  <a class="nav-link mb-sm-3 mb-md-0 active" id="tabs-text-1-tab" data-toggle="tab" href="#tabs-text-1" role="tab" aria-controls="tabs-text-1" aria-selected="true" style="font-size: 11px">Active</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link mb-sm-3 mb-md-0" id="tabs-text-2-tab" data-toggle="tab" href="#tabs-text-2" role="tab" aria-controls="tabs-text-2" aria-selected="false" style="font-size: 11px">Deactive</a>
                </li>
                <!-- <li class="nav-item">
                  <button type="button" class="btn btn-success float-right pull-right pl-5 pr-5" data-toggle="modal" data-target="#exampleModal" data-whatever="@getbootstrap"><i class="fas fa-plus"></i> Add <?php echo $page2 ?></button>
                </li> -->
              </ul>
            </div>




            
            <!-- <div class="col-lg-6 col-5 text-right">
              <a href="#" class="btn btn-sm btn-neutral">New</a>
              <a href="#" class="btn btn-sm btn-neutral">Filters</a>
            </div> -->
          </div>
          <!-- Card stats -->

        </div>
      </div>
    </div>

    <div class="container-fluid mt--6">
      <section class="content">
        <div class="row">
          <div class="col-12">
            <div class="card pb-4">

              <div class="tab-content" id="myTabContent">

                <div class="tab-pane fade show active" id="tabs-text-1" role="tabpanel" aria-labelledby="tabs-icons-text-1-tab">
                  <div class="card-header border-0">
                    <div class="row align-items-center">
                      
                    </div>
                  </div>
                  <div class="table-responsive">
                    <!-- Projects table -->
                    <table class="table align-items-center table-flush table-hover text-center mydatatable" id="myTable">
                      <thead class="thead-light" style="height: 70px">
                        <tr>
                          <th scope="col">No</th>
                          <th scope="col">Periode</th>
                          <th scope="col">No PO</th>
                          <th scope="col">Tanggal Service</th>
                          <th scope="col">KM (Rp)</th>
                          <th scope="col">Keterangan</th>
                          <th scope="col">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                          <?php $i = 1; ?>
                            @foreach($services as $service)
                            @if($service->active != '1')
                            <tr role="row" class="odd">
                              <td>{{$i}}</td>
                              <td >
                                  {{$service->periode}}
                              </td>
                              <td>
                                  @foreach($pos as $po)
                                    @if($service->po_id == $po->id)
                                      {{$po->NoPo}}
                                    @endif
                                  @endforeach
                              </td>
                              <td >
                                    @if($service->TglService != '')
                                      {{ date('d-M-Y', strtotime($service->TglService))}}
                                    @else
                                      
                                    @endif
                              </td>
                              <td >
                                    @if($service->km == '')
                                    @else
                                      @currency($service->km)
                                    @endif 
                              </td>
                              <td >
                                    {{$service->Keterangan}}
                              </td>
                              <td>
                                <a class="btn btn-success btn-sm" href="{{url('/backend/report/service/edit/'.$service->id)}}">
                                    <i class="fas fa-pencil-alt">
                                    </i>
                                    
                                </a>
                                <a class="btn btn-danger btn-sm" href="{{url('/backend/report/service/delete_report/'.$service->id)}}">
                                    <i class="fas fa-trash">
                                    </i>
                                    
                                </a>
                              </td>
                            </tr>
                            <?php $i++; ?>
                            @endif
                            @endforeach
                      </tbody>
                    </table>
                  </div>
                </div>


                <div class="tab-pane fade " id="tabs-text-2" role="tabpanel" aria-labelledby="tabs-icons-text-1-tab">
                  <div class="card-header border-0">
                    <div class="row align-items-center">
                      
                    </div>
                  </div>
                  <div class="table-responsive">
                    <!-- Projects table -->
                    <table class="table align-items-center table-flush table-hover text-center mydatatable" id="myTable">
                      <thead class="thead-light" style="height: 70px">
                        <tr>
                          <th scope="col">No</th>
                          <th scope="col">Periode</th>
                          <th scope="col">No PO</th>
                          <th scope="col">Tanggal Service</th>
                          <th scope="col">KM (Rp)</th>
                          <th scope="col">Keterangan</th>
                          <th scope="col">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $i = 1; ?>
                          @foreach($services as $service)
                          @if($service->active == '1')
                          <tr role="row" class="odd">
                            <td>{{$i}}</td>
                            <td >
                                {{$service->periode}}
                            </td>
                            <td>
                                @foreach($pos as $po)
                                  @if($service->po_id == $po->id)
                                    {{$po->NoPo}}
                                  @endif
                                @endforeach
                            </td>   
                            <td >
                                  @if($service->TglService != '')
                                    {{ date('d-M-Y', strtotime($service->TglService))}}
                                  @else
                                    
                                  @endif
                            </td>
                            <td >
                                  @if($service->km == '')
                                  @else
                                    @currency($service->km)
                                  @endif 
                            </td>
                            <td >
                                  {{$service->Keterangan}}
                            </td>
                            <td><a class="btn btn-info btn-sm" href="{{url('/backend/report/service/delete/'.$service->id)}}">
                                  <i class="fas fa-undo">
                                  </i>
                                  Restore
                              </a></td>
                          </tr>
                          <?php $i++; ?>
                          @endif
                          @endforeach
                      </tbody>
                    </table>
                  </div>
                </div>

              </div>

              
              
            </div>
            
          </div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

            
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </section>
    <!-- /.content -->
    </div>



@endsection

















