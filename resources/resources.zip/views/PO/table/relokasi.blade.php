

 
                    <div class="table-responsive">
                      <table class="table align-items-center table-flush table-hover text-center mydatatable" id="myTable" style="width: 100%">
                        <thead class="thead-light" style="height: 70px">
                          <tr>
                            <th scope="col" rowspan="2"><b>No</b></th>
                            <th scope="col" rowspan="2"><b>No PO</b></th>
                            <th scope="col" rowspan="2"><b>Jenis Sewa</b></th>
                            <th scope="col" rowspan="2"><b>CP/D</b></th>
                            <th scope="col" rowspan="2"><b>Merek & Type</b></th>
                            <th scope="col" rowspan="2"><b>Nopol</b></th>
                            <th scope="col" rowspan="2"><b>Vendor</b></th>
                            <th scope="col" colspan="4" class="bg-info text-white"><b>Cabang Baru</b></th>                
                            <th scope="col" rowspan="2"><b>Action</b></th>
                          </tr>
                          <tr>
                            <th scope="col" class="bg-info text-white"><b>No PO</b></th>
                            <th scope="col" class="bg-info text-white"><b>Cabang</b></th>
                            <th scope="col" class="bg-info text-white"><b>Kota</b></th>
                            <th scope="col" class="bg-info text-white"><b>Efektif</b></th>
                          </tr>
                        </thead>
                        <tbody>
                             <?php 
                            $i = 1;
                            $currentDateTime = date('Y-m-d H:i:s');
                          ?>
                          @foreach($pos as $po)
                          @if($po->status == 1 && $po->SelesaiSewa >= $currentDateTime && $po->Efisien_relokasi != '' && $po->Efisien_relokasi >= $currentDateTime)
                          <tr role="row" class="odd "> 
                            <td>{{$i}}</td>

                            <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->

                                <td>{{$po->Nopo_permanent}}</td>

                            <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->

                                <td>
                                    @if($po->Tgl_cutoff <= $currentDateTime && $po->Tgl_cutoff != '' && $po->Sewa_sementara != 'null')
                                      {{$po->Sewa_sementara}}
                                    @elseif($po->Tgl_cutoff <= $currentDateTime && $po->Tgl_cutoff != '' && $po->Sewa_sementara == 'null')
                                      {{$po->Sewa}} (Cutoff)
                                    @elseif($po->Tgl_cutoff <= $currentDateTime && $po->Tgl_cutoff != '' && $po->Sewa_sementara == 'null')
                                    @else
                                      {{$po->Sewa}}
                                    @endif
                                </td>
                                

                             <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->   
                                
                                <td>{{$po->CP}}</td>

                             <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->

                                <td>

                                  @if($po->Mobil_id == 'null')
                                    Tanpa Unit
                                  @elseif($po->Mobil_id == '')
                                    Tanpa Unit
                                  @else
                                    @foreach($mobils as $mobil)
                                      @if($po->Mobil_id == $mobil->id)
                                        {{$mobil->MerekMobil}} {{$mobil->Type}} 
                                      @endif
                                    @endforeach
                                  @endif

                                  
                                </td>

                              <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->

                                <td>

                                  @if($po->Nopol == 'null')
                                    Tanpa Unit
                                  @elseif($po->Nopol == '')
                                    Tanpa Unit
                                  @else
                                    {{$po->Nopol}}
                                  @endif
                            
                                </td>

                              <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->

                                <td>
                                  @foreach($vendors as $vendor)
                                    @if($po->Vendor_Driver == $vendor->id)
                                      {{$vendor->NamaVendor}}
                                    @endif
                                  @endforeach
                                </td>


                                <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->


                            
                            
                            @if($po->Cabang_relokasi == '')
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                            @else
                                  
                                  <td>{{$po->Nopo_relokasi}}</td>
                                  @foreach($cabangs as $cabang)
                                
                                    @if($po->Cabang_relokasi == $cabang->id)
                                    <td>{{$cabang->KodeCabang}} - {{$cabang->NamaCabang}}</td>
                                    <td>{{$cabang->Kota}}</td>
                                    @endif
                                
                                  @endforeach
                                  
                            @endif
                            <td>
                              @if($po->Efisien_relokasi == '')
                                -
                              @else
                                {{$po->Efisien_relokasi->format('d-M-Y')}}
                              @endif
                            </td>

                            <td>
                                @if(auth::user()->status == 'operasional' || auth::user()->status == 'admin')

                                <a class="btn btn-info btn-sm" href="{{url('/backend/po/edit_dashboard/'.$po->id)}}" >
                                    <i class="fas fa-pencil-alt" >
                                    </i>
                                    
                                </a>

                                @endif
                                <a class="btn btn-warning btn-sm" href="{{url('/backend/po/show/'.$po->id)}}">
                                    <i class="fas fa-folder">
                                    </i>
                                    Lihat detail
                                </a>
                            </td>

                            <?php $i++; ?>
                          </tr>
                          @endif
                          @endforeach
                           
                        </tbody>
                      </table>
                    </div>
                