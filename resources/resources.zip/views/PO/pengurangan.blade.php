<?php $page = "Pengurangan"; ?>
@extends('sidebar')

@section('content')



<div class="header bg-primary pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h1 class=" text-white d-inline-block mb-0">{{$page}} Table</h1>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">Purchase Order</a></li>
                  <li class="breadcrumb-item active" aria-current="page">table</li>
                </ol>
              </nav>
            </div>
            <div class="col-lg-6 col-5 text-right">
              <a href="{{url('/backend/po/table')}}" type="button" class="btn btn-default">Back</a>
              <!-- <a href="/backend/po/form_add" class="btn btn-success float-right pull-right" ><i class="fas fa-plus"></i> Add <?php echo $page ?></a> -->
            </div>
            <!-- <div class="col-lg-6 col-5 text-right">
              <a href="#" class="btn btn-sm btn-neutral">New</a>
              <a href="#" class="btn btn-sm btn-neutral">Filters</a>
            </div> -->
          </div>
          <!-- Card stats -->

        </div>
      </div>
    </div>
    <div class="container-fluid mt--6">
      <section class="content">
        <div class="row">
          <div class="col-12">
            <div class="card pb-4 pt--8">
              <div class="card-header border-0">
                
              </div>
              <div class="">
                <!-- Projects table -->
                <div class="table-responsive">
                  <table class="table  align-items-center table-flush table-hover text-center mydatatable" id="myTable">
                    <thead class="thead-light">
                      <tr>
                        <th scope="col"><b>No</b></th>
                        <th scope="col"><b>No PO</b></th>
                        <th scope="col" class="bg-danger text-white"><b>Jenis Sewa</b></th>
                        <th scope="col"><b>CP/D</b></th>
                        <th scope="col"><b>Nopol</b></th>
                        <th scope="col"><b>Vendor</b></th>
                        <th scope="col"><b>Cabang</b></th>
                        <th scope="col"><b>Kota</b></th>
                        <th scope="col"><b>Mulai Sewa</b></th>                       
                        <th scope="col"><b>Selesai Sewa</b></th>
                        <th scope="col" class="bg-danger text-white"><b>Pengurangan</b></th>
                        <th scope="col" class="bg-danger text-white"><b>Cut Off</b></th>
                        <th scope="col"><b>Action</b></th>
                      </tr>
                    </thead>
                    <tbody>
                         <?php 
                        $i = 1;
                        $currentDateTime = date('Y-m-d H:i:s');
                      ?>
                      @foreach($pos as $po)
                      @if($po->status == 1 && ($po->SelesaiSewa <= $currentDateTime || ($po->Tgl_cutoff != '' && $po->Tgl_cutoff <= $currentDateTime && $po->Sewa_sementara == 'null')))
                      @elseif($po->status == '0')
                      @else
                      <tr role="row" class="odd ">
                        <td>{{$i}}</td>
                        <td>{{$po->Nopo_permanent}}
                        </td>
                        <!-- <td>
                          @foreach($nopos as $nopo)
                            @if($po->NoPo == $nopo->id)
                              {{$nopo->NoPo}}
                            @endif
                          @endforeach
                        </td> -->
                        <td>{{$po->Sewa}}</td>
                        <td>{{$po->CP}}</td>
                        <td>

                            @if($po->Nopol == 'null')
                              Tanpa Unit
                            @elseif($po->Nopol == '')
                              Tanpa Unit
                            @else
                              {{$po->Nopol}}
                            @endif
 
                          </td>
                        <td>
                          @foreach($vendors as $vendor)
                            @if($po->Vendor_Driver == $vendor->id)
                              {{$vendor->NamaVendor}}
                            @endif
                          @endforeach
                        </td>
                        <td>
                          @foreach($cabangs as$cabang)
                            @if($po->Cabang_id == $cabang->id)
                              {{$cabang->KodeCabang}} - {{$cabang->NamaCabang}}
                            @endif
                          @endforeach
                        </td>
                        <td> 
                          @foreach($cabangs as$cabang)
                            @if($po->Cabang_id == $cabang->id)
                              {{$cabang->Kota}}
                            @endif
                          @endforeach
                        </td>
                        <td>
                          {{$po->MulaiSewa->format('d-M-Y')}}
                        </td>
                        <td>
                          {{$po->SelesaiSewa->format('d-M-Y')}}
                        </td>

                        <td>
                          @if($po->Pengurangan == '')
                            -
                          @else
                            {{$po->Pengurangan}}
                          @endif
                          
                        </td>

                        <td>
                          @if($po->Tgl_cutoff == '')
                            -
                          @else
                            {{$po->Tgl_cutoff->format('d-M-Y')}}
                          @endif
                        </td>
                        
                        <td>
                          @if($po->Sewa_sementara == "null")
                          <a class="btn btn-warning btn-sm disabled" href="{{url('/backend/po/form_pengurangan/'.$po->id)}}">
                              Pengurangan
                          </a>
                          @else
                          <a class="btn btn-warning btn-sm" href="{{url('/backend/po/form_pengurangan/'.$po->id)}}">
                              Pengurangan
                          </a>
                          @endif
                          
                        </td>

                        <?php $i++; ?>
                      </tr>
                      @endif
                      @endforeach
                       
                    </tbody>
                  </table>
                </div>
                
              </div>
              
            <!-- /.card -->
            
          </div>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

            
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </section>
    <!-- /.content -->
    </div>



<script>


</script>

@include('PO.add');

@endsection






