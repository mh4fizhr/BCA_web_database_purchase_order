<div class="table-responsive">
  <table class="table align-items-center table-flush table-hover text-center mydatatable">
    <thead class="thead-light" style="height: 70px">
      <tr>
        <th scope="col"><b>No</b></th>
        <th scope="col"><b>No PO</b></th>
        <th scope="col"><b>Jenis Sewa</b></th>
        <th scope="col"><b>CP/D</b></th>
        <th scope="col"><b>Vendor</b></th>
        <th scope="col"><b>Cabang</b></th>
        <th scope="col"><b>Kota</b></th>
        <th scope="col"><b>Mulai Sewa</b></th>                       
        <th scope="col"><b>Selesai Sewa</b></th>
        <th scope="col"><b>Harga Sewa Mobil</b></th>
        <th scope="col"><b>Harga Sewa Driver</b></th>
        <th scope="col"><b>Total Harga</b></th>
        <th scope="col"><b>Status</b></th>
        <th scope="col"><b>Action</b></th>
      </tr>
    </thead>
    <tbody>
       <?php 
      $i = 1;
    ?>
    @foreach($pos as $po)
        @if($po->status == '0')
    <tr role="row" class="odd ">
      <td>{{$i}}</td>
      <td>{{$po->Nopo_permanent}}</td>
    <!-- <td>
      @foreach($nopos as $nopo)
        @if($po->NoPo == $nopo->id)
          {{$nopo->NoPo}}
        @endif
      @endforeach
    </td> -->
      <td>{{$po->Sewa}}</td>
      <td>{{$po->CP}}</td>
      <td>
        @foreach($vendors as $vendor)
          @if($po->Vendor_Driver == $vendor->id)
            {{$vendor->NamaVendor}}
          @endif
        @endforeach
      </td>
      <td>
        @foreach($cabangs as$cabang)
          @if($po->Cabang_id == $cabang->id)
            {{$cabang->KodeCabang}} - {{$cabang->NamaCabang}}
          @endif
        @endforeach
      </td>
      <td> 
        @foreach($cabangs as$cabang)
          @if($po->Cabang_id == $cabang->id)
            {{$cabang->Kota}}
          @endif
        @endforeach
      </td>
      <td><!-- <a href="#" class="po_tgl" 
        data-name="mulaisewa" 
        data-type="date" 
        data-pk="{{$po->id}}" 
        data-url="/api/backend/po/tgl/update/{{$po->id}}" 
        data-title="Masukkan tanggal Mulai Sewa" >
        {{$po->MulaiSewa->format('d-M-Y')}}</a> -->
        {{$po->MulaiSewa->format('d-M-Y')}}
      </td>
      <td><!-- <a href="#" class="po_tgl" 
        data-name="selesaisewa" 
        data-type="date" 
        data-pk="{{$po->id}}" 
        data-url="/api/backend/po/tgl/update/{{$po->id}}" 
        data-title="Masukkan tanggal selesai sewa" >
        {{$po->SelesaiSewa->format('d-M-Y')}}</a> -->
        {{$po->SelesaiSewa->format('d-M-Y')}}
      </td>
      <td><!-- <a href="#" class="tglpo" 
        data-name="hargasewamobil" 
        data-type="number" 
        data-pk="{{$po->id}}" 
        data-url="/api/backend/po/tgl/update/{{$po->id}}" 
        data-title="Masukkan Nominal Harga sewa mobil" >
        @currency($po->HargaSewaMobil)</a> -->
        @currency($po->HargaSewaMobil)
      </td>
      <td><!-- <a href="#" class="tglpo" 
        data-name="hargasewadriver2019" 
        data-type="number" 
        data-pk="{{$po->id}}" 
        data-url="/api/backend/po/tgl/update/{{$po->id}}" 
        data-title="Masukkan Nominal Harga sewa mobil" >
        @currency($po->HargaSewaDriver2019)</a> -->
        @currency($po->HargaSewaDriver2019)
      </td>

      <td>
        <?php $hsmd = $po->HargaSewaDriver2019 + $po->HargaSewaMobil ?>
        @currency($hsmd)</a>
      </td>
      <td>
        @if($po->Status == 0)
        <span class="badge badge-danger">On Process</span>
        @else
        <span class="badge badge-success">complete</span>
        @endif
      </td>
      <td>
        <a class="btn btn-info btn-sm" href="{{url('/backend/po/edit_pengada/'.$po->id)}}" >
            <i class="fas fa-pencil-alt" >
            </i>
            Edit
        </a>
        <a href="{{url('/backend/po/delete/'.$po->id)}}" class="btn btn-sm btn-warning" ><i class="fas fa-times"></i>&nbsp Delete PO</a>
      </td>


      <?php $i++; ?>
    </tr>
    @endif
    @endforeach
    </tbody>
  </table>
</div>

























