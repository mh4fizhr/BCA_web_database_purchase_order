<div class="modal fade" id="filter" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Filter Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="{{url('/backend/dashboard')}}" method="post" role="form">
          {{ csrf_field() }}
          <div class="card-body">

            <div class="row form-group">
              <!-- ``````````````````````````````````````````````````````````````````` -->
              <div class="col-md-3">
                    <div class="form-group">
                      <label class="form-control-label ml-3 " for="example3cols1Input">No PO :</label>
                    </div>
                    <div id="nopo_ajax"></div>
              </div>
              <div class="col-md-9">
                    <div class="form-group">
                      <!-- <input type="text" class="form-control" name="nopo" id="example3cols2Input" placeholder="Example : 256/JS/BPD/KPS/2017"> -->
                      <input type="text" id="nopo" class="form-control form-control-sm" name="nopo">
                    </div>
              </div>
              <!-- ``````````````````````````````````````````````````````````````````` -->
              <div class="col-md-3">
                <div class="form-group" id="contoh_tambahan">
                  <label class="form-control-label ml-3 " for="example3cols1Input">Jenis Sewa :</label>
                </div>
              </div>
              <div class="col-md-9">
                <div class="form-group">
                  <select class="form-control form-control-sm" id="sewa" name="sewa">
                    <option value=""></option>
                    <option value="Mobil+Driver">Mobil + Driver</option>
                    <option value="Mobil">Mobil</option>
                    <option value="Driver">Driver</option>
                  </select>
                </div>
              </div>
              <!-- ``````````````````````````````````````````````````````````````````` -->
              <div class="col-md-3">
                <div class="form-group" id="contoh_tambahan">
                  <label class="form-control-label ml-3 " for="example3cols1Input">Nopol :</label>
                </div>
              </div>
              <div class="col-md-9">
                <input type="text" id="nopol" class="form-control form-control-sm" name="nopol">
              </div>
              <!-- ``````````````````````````````````````````````````````````````````` -->
              <div class="col-md-3">
                <div class="form-group">
                  <label class="form-control-label ml-3 " for="example3cols1Input">CP/D :</label>
                </div>
              </div>
              <div class="col-md-9">
                <div class="form-group">
                  <select class="form-control form-control-sm" id="CP" name="CP">
                    <option value=""></option>
                    <option value="CP">CP - Carpooling</option>
                    <option value="D">D - Dedicated</option>
                  </select>
                </div>
              </div>
              <!-- ``````````````````````````````````````````````````````````````````` -->
              <div class="col-md-3">
                    <div class="form-group">
                      <label class="form-control-label ml-3 " for="example3cols1Input">Type/Unit :</label>
                    </div>
              </div>
              <div class="col-md-9">
                    <div class="form-group">
                      <select class="form-control form-control-sm select2" id="type" name="mobil_id">
                        <option value=""></option>
                        <!-- <option value="null">Tanpa Unit</option> -->
                        @foreach($mobils as $mobil)
                          @if($mobil->active != '1')
                          <option value="{{$mobil->id}}">{{$mobil->MerekMobil}}&nbsp{{$mobil->Type}}&nbsp- {{$mobil->Tahun}}</option>
                          @endif
                        @endforeach

                      </select>
                    </div>
              </div>
              <!-- ``````````````````````````````````````````````````````````````````` -->
              <div class="col-md-3">
                <div class="form-group">
                  <label class="form-control-label ml-3 " for="example3cols1Input">Vendor :</label>
                </div>
              </div>
              <div class="col-md-9">
                <div class="form-group">
                  <select class="form-control form-control-sm select2" id="vendor" name="vendor_id" data-toggle="select" title="Simple select" data-live-search="true" data-live-search-placeholder="Search ...">
                    <option value=""></option>
                    @foreach($vendors as $vendor)
                      @if($vendor->active != '1')
                        <option value="{{$vendor->id}}">{{$vendor->NamaVendor}}</option>
                      @endif
                    @endforeach
                  </select>
                </div>
              </div>
              <!-- ``````````````````````````````````````````````````````````````````` -->
              <div class="col-md-3">
                <div class="form-group">
                  <label class="form-control-label ml-3 " for="example3cols1Input">Cabang & Kota:</label>
                </div>
              </div>
              <div class="col-md-9">
                <div class="form-group">
                  <select class="form-control form-control-sm cabang select2" id="cabang" name="cabang_id" data-toggle="select" title="Simple select" data-live-search="true" data-live-search-placeholder="Search ...">
                    <option value=""></option>
                    <?php $ckota = "" ?>
                    @foreach($cabangs as $cabang)
                      @if($cabang->active != '1')
                        <option value="{{$cabang->id}}">{{$cabang->KWL}} - {{$cabang->KodeCabang}} - {{$cabang->NamaCabang}} - {{$cabang->Kota}}</option>
                      @endif
                    <?php $ckota = $cabang->Kota ?>
                    @endforeach
                  </select>
                </div>
              </div>
              <!-- ``````````````````````````````````````````````````````````````````` -->
              <div class="col-md-3">
                <div class="form-group">
                  <label class="form-control-label ml-3 " for="example3cols1Input">Mulai Sewa :</label>
                </div>
              </div>
              <div class="col-md-9">
                <div class="form-group">
                  <input class="form-control form-control-sm date" type="text" name="mulaisewa" id="mulaisewa" placeholder="mm / dd / yyyy">
                </div>
              </div>
              <!-- ``````````````````````````````````````````````````````````````````` -->
              <div class="col-md-3">
                <div class="form-group">
                  <label class="form-control-label ml-3 " for="example3cols1Input">Selesai Sewa :</label>
                </div>
              </div>
              <div class="col-md-9">
                <div class="form-group">
                  <input class="form-control form-control-sm date" type="text" name="selesaisewa" id="selesaisewa" placeholder="mm / dd / yyyy">
                </div>
              </div>
              <!-- ``````````````````````````````````````````````````````````````````` -->
              <div class="col-md-3">
                <div class="form-group" id="contoh_tambahan">
                  <label class="form-control-label ml-3 " for="example3cols1Input">Status :</label>
                </div>
              </div>
              <div class="col-md-9">
                <div class="form-group">
                  <select class="form-control form-control-sm" id="sewa" name="sewa">
                    <option value=""></option>
                    <option value="active">active</option>
                    <option value="not active">not active</option>
                  </select>
                </div>
              </div>
              
          </div>
          <!-- /.card-body -->
          <div class="float-right mb-5">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-success">Search</button>
          </div>
        </form>
      </div>
      
    </div>
  </div>
</div>