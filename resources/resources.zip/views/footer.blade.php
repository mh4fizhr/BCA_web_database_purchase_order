
@yield('section')

      <!-- Footer -->
      <!-- <footer class="footer pt-0">
        <div class="row align-items-center justify-content-lg-between">
          <div class="col-lg-6">
            <div class="copyright text-center  text-lg-left  text-muted">
              &copy; 2020 <a href="https://www.creative-tim.com" class="font-weight-bold ml-1" target="_blank">Creative Tim</a>
            </div>
          </div>
          <div class="col-lg-6">
            <ul class="nav nav-footer justify-content-center justify-content-lg-end">
              <li class="nav-item">
                <a href="https://www.creative-tim.com" class="nav-link" target="_blank">Creative Tim</a>
              </li>
              <li class="nav-item">
                <a href="https://www.creative-tim.com/presentation" class="nav-link" target="_blank">About Us</a>
              </li>
              <li class="nav-item">
                <a href="http://blog.creative-tim.com" class="nav-link" target="_blank">Blog</a>
              </li>
              <li class="nav-item">
                <a href="https://github.com/creativetimofficial/argon-dashboard/blob/master/LICENSE.md" class="nav-link" target="_blank">MIT License</a>
              </li>
            </ul>
          </div>
        </div>
      </footer> -->
    </div>
  </div>
  <!-- Argon Scripts -->
  <!-- Core -->
  <!-- <script src="{{asset('dist/argon/vendor/jquery/dist/jquery.min.js')}}"></script> -->
<!--   <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js" integrity="sha256-VazP97ZCwtekAsvgPBSUwPFKdrwD3unUfSGVYrahUqU=" crossorigin="anonymous"></script> -->
  <script src="{{asset('dist/argon/vendor/bootstrap/dist/js/bootstrap.bundle.min.js')}}"></script>
  <script src="{{asset('dist/argon/vendor/js-cookie/js.cookie.js')}}"></script>
  <script src="{{asset('dist/argon/vendor/jquery.scrollbar/jquery.scrollbar.min.js')}}"></script>
  <script src="{{asset('dist/argon/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js')}}"></script>
  <!-- Optional JS -->
  <script src="{{asset('dist/argon/vendor/chart.js/dist/Chart.min.js')}}"></script>
  <script src="{{asset('dist/argon/vendor/chart.js/dist/Chart.extension.js')}}"></script>
  <!-- Argon JS -->
  <script src="{{asset('dist/argon/js/argon.js?v=1.2.0')}}"></script>
  <script src="{{asset('dist/bootstrap4-editable/js/bootstrap-editable.js')}}"></script>
  <!-- Plugin Js -->
  <script src="{{asset('dist/argon/vendor/bootstrap-notify/bootstrap-notify.min.js')}}"></script>


  <script src="{{asset('dist/argon/vendor/datatables.net/js/jquery.dataTables.min.js')}}"></script>
  <script src="{{asset('dist/argon/vendor/datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>
  <script src="{{asset('dist/argon/vendor/datatables.net-buttons/js/dataTables.buttons.min.js')}}"></script>
  <script src="{{asset('dist/argon/vendor/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js')}}"></script>
  <script src="{{asset('dist/argon/vendor/datatables.net-buttons/js/buttons.html5.min.js')}}"></script>
  <script src="{{asset('dist/argon/vendor/datatables.net-buttons/js/buttons.flash.min.js')}}"></script>
  <script src="{{asset('dist/argon/vendor/datatables.net-buttons/js/buttons.print.min.js')}}"></script>
  <script src="{{asset('dist/argon/vendor/datatables.net-select/js/dataTables.select.min.js')}}"></script>
  <script src="{{asset('dist/argon/vendor/select2/dist/js/select2.min.js')}}"></script>
  <script src="{{asset('dist/argon/vendor/dropzone/dist/min/dropzone.min.js')}}"></script>
<!--   <script src="{{asset('dist/dropzone/dist/min/dropzone.min.js')}}"></script> -->


  <script src="{{asset('dist/argon/vendor/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')}}"></script>
  <!-- <script src="{{asset('dist/sweetalert/dist/sweetalert2.min.js')}}"></script> -->
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  @include('sweet::alert')

  <script src="{{asset('dist/js/autoNumeric/autoNumeric.js')}}"></script>

  <!--   <script src="{{asset('dist/argon/vendor/jquery/dist/jquery.min.js')}}"></script> -->









  
<script>
  $(function () {

    // Initialization
    $('.date').datepicker(
      { dateFormat: 'mm-dd-yy' }
      ).val();

    //Initialize Select2 Elements
    $('.select2').select2();

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    });

    // //Datemask dd/mm/yyyy
    // $('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
    // //Datemask2 mm/dd/yyyy
    // $('#datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' })
    // //Money Euro
    // $('[data-mask]').inputmask()

    // //Date range picker
    // $('#reservation').daterangepicker()
    // //Date range picker with time picker
    // $('#reservationtime').daterangepicker({
    //   timePicker: true,
    //   timePickerIncrement: 30,
    //   locale: {
    //     format: 'MM/DD/YYYY hh:mm A'
    //   }
    // })
    // //Date range as a button
    // $('#daterange-btn').daterangepicker(
    //   {
    //     ranges   : {
    //       'Today'       : [moment(), moment()],
    //       'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
    //       'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
    //       'Last 30 Days': [moment().subtract(29, 'days'), moment()],
    //       'This Month'  : [moment().startOf('month'), moment().endOf('month')],
    //       'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
    //     },
    //     startDate: moment().subtract(29, 'days'),
    //     endDate  : moment()
    //   },
    //   function (start, end) {
    //     $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
    //   }
    // )

    // //Timepicker
    // $('#timepicker').datetimepicker({
    //   format: 'LT'
    // })
    
    // //Bootstrap Duallistbox
    // $('.duallistbox').bootstrapDualListbox()

    // //Colorpicker
    // $('.my-colorpicker1').colorpicker()
    // //color picker with addon
    // $('.my-colorpicker2').colorpicker()

    // $('.my-colorpicker2').on('colorpickerChange', function(event) {
    //   $('.my-colorpicker2 .fa-square').css('color', event.color.toString());
    // });

    // $("input[data-bootstrap-switch]").each(function(){
    //   $(this).bootstrapSwitch('state', $(this).prop('checked'));
    // });

    $('[data-toggle="tooltip"]').tooltip();



  });

    // $(document).ready(function() {
    //     $('.tglpo').editable({
    //     });
    //     $('.po_tgl').editable({
    //         format: 'dd-MM-yyyy',    
    //         viewformat: 'dd-MM-yyyy',    
    //         datepicker: {
    //                 weekStart: 1
    //            }
    //         });
    //     $('.driver').editable({
    //     });
    //     $('.mobil').editable({
    //     });
    //     $('.pkwt').editable({
    //     });
    //     $('.driver_pkwt').editable({
    //         format: 'dd-MM-yyyy',    
    //         viewformat: 'dd-MM-yyyy',    
    //         datepicker: {
    //                 weekStart: 1
    //            }
    //         });
    //     $('.service').editable({
    //     });
    //     $('.mcu').editable({
    //     });
    //     $('.ump').editable({
    //     });
    //     $('.user').editable({
    //     });
    //     $('.kota').editable({
    //     });
    //     $('.jkk').editable({
    //     });
    //     $('.user_status').editable({
    //       value: 'pengadaan',    
    //       source: [
    //             {value: 'pengadaan', text: 'pengadaan'},
    //             {value: 'penyedia', text: 'penyedia'},
    //             {value: 'admin', text: 'admin'}
    //          ]
    //     });
    // });

    $(document).ready(function() {
        $('.mydatatable').DataTable({
          "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
        // scrollY:        '100%',
        // scrollCollapse: true,
        // responsive: true,
         order: false,
         columnDefs: [{
             targets: "_all",
             orderable: false
         }],
            language: {
               paginate: {
               next: '<i class="fas fa-angle-right">',
               previous: '<i class="fas fa-angle-left">'  
                }
             }
        });

        $('.myTable').DataTable({
          "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
            language: {
               paginate: {
               next: '<i class="fas fa-angle-right">',
               previous: '<i class="fas fa-angle-left">'  
                }
             }
        });

      });
      
    
</script>

<script type="text/javascript">

    $.ajaxSetup({

        headers: {

            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

        }

    });

    // $('#vendor').on('change', function(e) {

    //           e.preventDefault();

    //           var kota = $('#cabang').val();

    //           var vendor = $(this).val();

    //           $.ajax({

    //                type:'POST',

    //                url:'{{ route('kota_ajax') }}',

    //                dataType:"json",

    //                data:{"_token": "{{ csrf_token() }}",kota:kota, vendor:vendor},

    //                success:function(data){

    //                   $('#harga_driver_ajax_empty').empty();

    //                     $.each(data, function(key, value) {


    //                       $('#harga_driver').val(value.Harga_include);


    //                     });

    //                }

    //           });

    //     });

    $('#cabang').on('change', function(e) {

                    e.preventDefault();

                    var kota = $(this).val();

                    var vendor = $('#vendor').val();

                    $.ajax({

                         type:'POST',

                         url:'{{ route('kota_ajax') }}',

                         dataType:"json",

                         data:{"_token": "{{ csrf_token() }}",kota:kota, vendor:vendor},

                         success:function(data){

                            $('#harga_driver_ajax_empty').empty();

                              $('#harga_driver_hidden').val('0');
                                $('#harga_driver').val('0');
                                $('#harga_driver_eksclude_disabled').val('0');

                              $.each(data, function(key, value) {

                                // $('#harga_driver').val(value.Harga_include);

                                $('#harga_driver_hidden').val(value.Harga_include);
                                var hasil = value.Harga_include.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                                $('#harga_driver').val(hasil);
                                
                                var hasil_eksclude = value.Harga_eksclude.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                                $('#harga_driver_eksclude_disabled').val(hasil_eksclude);


                              });

                         }

                    });

              });

    $('#vendor').on('change', function(e) {

                    e.preventDefault();

                    var kota = $('#cabang').val();

                    var vendor = $(this).val();

                    $.ajax({

                         type:'POST',

                         url:'{{ route('kota_ajax') }}',

                         dataType:"json",

                         data:{"_token": "{{ csrf_token() }}",kota:kota, vendor:vendor},

                         success:function(data){

                            $('#harga_driver_ajax_empty').empty();

                              $('#harga_driver_hidden').val('0');
                                $('#harga_driver').val('0');
                                $('#harga_driver_eksclude_disabled').val('0');

                              $.each(data, function(key, value) {

                                // $('#harga_driver').val(value.Harga_include);

                                $('#harga_driver_hidden').val(value.Harga_include);
                                var hasil = value.Harga_include.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                                $('#harga_driver').val(hasil);
                                
                                var hasil_eksclude = value.Harga_eksclude.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
                                $('#harga_driver_eksclude_disabled').val(hasil_eksclude);


                              });

                         }

                    });

              });



</script>



<script type="text/javascript">

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    

    $(document).ready(function() {
      
      
        // $('#cabang').on('change', function() {

        //   var stateID = $(this).val();

        //   $('#vendor').on('change', function() {

        //     var vendorID = $(this).val();

        //     if(stateID) {

        //         $.ajax({

        //             url: '/backend/kota/ajax/'+stateID+'/'+vendorID,

        //             type: "GET",

        //             dataType: "json",

        //             success:function(data) {


        //                 $('#harga_driver_ajax_empty').empty();

        //                 $.each(data, function(key, value) {


        //                   $('#harga_driver').val(value.Harga_include);


        //                 });


        //             }

        //         });

        //     }else{

        //         $('#harga_driver_ajax').empty();

        //     }

        //   });

        // });



        // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        

          


    });
</script>


</body>


</html>