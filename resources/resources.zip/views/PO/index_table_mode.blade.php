<?php $page = "DPO"; ?>
@extends('sidebar')

@section('content')



<div class="header bg-primary pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">
              <h1 class=" text-white d-inline-block mb-0">{{$page}} Table</h1>
              <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                  <li class="breadcrumb-item"><a href="#"><i class="fas fa-home"></i></a></li>
                  <li class="breadcrumb-item"><a href="#">Purchase Order</a></li>
                  <li class="breadcrumb-item active" aria-current="page">table</li>
                </ol>
              </nav>
            </div>
            <div class="col-lg-6 col-5 text-right">
              <div class="float-right pull-right">
                 
                @if(auth::user()->status == 'pengada')
                  <a href="{{url('/backend/po/form_add')}}" class="btn btn-secondary  mr-2 ml-2 mt-2" ><i class="fas fa-plus"></i> PO </a>

                  <a href="{{url('/backend/po/relokasi')}}" class="btn btn-secondary  mr-2 ml-2 mt-2" ><i class="fas fa-share"></i> &nbspRelokasi </a>

                  <a href="{{url('/backend/po/pengurangan')}}" class="btn btn-secondary  mr-2 ml-2 mt-2" ><i class="fas fa-minus"></i> &nbspPengurangan</a>
                @endif

              </div>
            </div>
            <!-- <div class="col-lg-6 col-5 text-right">
              <a href="#" class="btn btn-sm btn-neutral">New</a>
              <a href="#" class="btn btn-sm btn-neutral">Filters</a>
            </div> -->
          </div>
          <!-- Card stats -->

        </div>
      </div>
    </div>
    <div class="container-fluid mt--6">
      <section class="content">
        <div class="row">
          <div class="col-12">
            <div class="card pb-4 pt--8">
              <div class="card-header border-0">
                <div class="row">
                  <div class="col-md-6">
                      <div class="dropdown">
                        <a href="{{url('/backend/po/table')}}" class="btn btn-default dropdown-toggle " data-toggle="dropdown" id="navbarDropdownMenuLink2">
                            <i class="ni ni-paper-diploma"></i> &nbsp 
                            @if($kategori == 1)
                            Penambahan
                            @elseif($kategori == 2)
                            Relokasi
                            @elseif($kategori == 3)
                            Pengurangan
                            @else
                              @if(auth::user()->status == 'pengada')

                                PO - on process

                              @elseif(auth::user()->status == 'operasional')

                                PO - from BPD

                              @endif
                            @endif
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink2">

                            <li>
                                <a class="dropdown-item <?php if($kategori == 0) echo('bg-primary text-white') ?>" href="{{url('/backend/po/table')}}">
                                  <i class="ni ni-paper-diploma"></i> 
                                  @if(auth::user()->status == 'pengada')

                                    PO - on process

                                  @elseif(auth::user()->status == 'operasional')

                                    PO - from BPD

                                  @endif
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item <?php if($kategori == 1) echo('bg-primary text-white') ?>" href="{{url('/backend/po/table/1')}}">
                                  <i class="fas fa-plus"></i> Penambahan
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item <?php if($kategori == 2) echo('bg-primary text-white') ?>" href="{{url('/backend/po/table/2')}}">                                  
                                  <i class="fas fa-share"></i> Relokasi
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item <?php if($kategori == 3) echo('bg-primary text-white') ?>" href="{{url('/backend/po/table/3')}}">
                                  <i class="fas fa-minus"></i> Pengurangan
                                </a>
                            </li>
                        </ul>
                      </div>
                      <!-- <li class="nav-item">
                        <a class="nav-link mb-sm-3 mb-md-0 active" id="tabs-icons-text-1-tab" data-toggle="tab" href="#tabs-icons-text-1" role="tab" aria-controls="tabs-icons-text-1" aria-selected="true" style="font-size: 12px">
                        @if(auth::user()->status == 'pengada')

                          PO - on process

                        @elseif(auth::user()->status == 'operasional')

                          PO - from BPD

                        @endif
                        </a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link mb-sm-3 mb-md-0" id="tabs-icons-text-2-tab" data-toggle="tab" href="#tabs-icons-text-2" role="tab" aria-controls="tabs-icons-text-2" aria-selected="false" style="font-size: 12px">Penambahan</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link mb-sm-3 mb-md-0" id="tabs-icons-text-3-tab" data-toggle="tab" href="#tabs-icons-text-3" role="tab" aria-controls="tabs-icons-text-3" aria-selected="false" style="font-size: 12px">Pengurangan</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link mb-sm-3 mb-md-0" id="tabs-icons-text-4-tab" data-toggle="tab" href="#tabs-icons-text-4" role="tab" aria-controls="tabs-icons-text-4" aria-selected="false" style="font-size: 12px">Relokasi</a>
                      </li> -->
                  </div>
                  <div class="col-md-4"></div>
                  <div class="col-md-2"></div>
                </div>
              </div>
              <div class="tab-content" id="myTabContent">
                <!-- Projects table -->
                @if($kategori == 1)
                
                  @include('PO.table.penambahan')
                
                @elseif($kategori == 2)
                
                  @include('PO.table.relokasi')
                
                @elseif($kategori == 3)
                
                  @include('PO.table.pengurangan')
                
                @else
                
                  @if(auth::user()->status == 'pengada')

                    @include('PO.table.table_pengada')

                  @elseif(auth::user()->status == 'operasional')

                    @include('PO.table.table_operasional')

                  @else

                    @include('PO.table.table_admin');

                  @endif
                
                @endif

                
                
                
                
                
                
              </div>

              
            <!-- /.card -->
            
            </div>
          </div>
              <!-- /.card-body -->
        </div>
            <!-- /.card -->

            
        <!-- /.card -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </section>
<!-- /.content -->
</div>



<script>
  
                     
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tbody tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>

@include('PO.add');

@endsection






